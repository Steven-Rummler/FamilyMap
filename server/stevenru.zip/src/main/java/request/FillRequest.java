package request;

public class FillRequest {
    /**
     * The user of the tree to fill
     */
    public String user;
    /**
     * The number of generations to fill
     */
    public Integer generations;
}
